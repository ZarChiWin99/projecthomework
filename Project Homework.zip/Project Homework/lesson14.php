<?php
    $b="welcome <br>";
	echo str-repat($b,10);
	?>
	<hr>
	<?php
	$a="cdcc";
	echo str-replace("c","p",$a);
	?>
	
	<hr>
	<?php
	$str="hello user how r you";
	?>
	<hr>
	<?php
	$str="welcome to the world of php";
	echo substr($str,24,3);
	?>
	<hr>
	<$php
	$num=19.7;
	echo floor ($num)."<br>"
	$num=19.2;
	echo floor($num)."<br>";
	?>php
	<?php
	echo rand(0,99);
	?><hr/>
	
	
